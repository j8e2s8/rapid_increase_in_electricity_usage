# 라이브러리 호출
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.font_manager as fm
import matplotlib as mpl
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PowerTransformer
from statsmodels.tsa.statespace.sarimax import SARIMAX


# 필요한 데이터 불러오기
df = pd.read_csv("./프로젝트2주차/data_week2.csv", encoding='cp949')

# ----------train/test설정--------------

# 데이터 불러오기
data_df = pd.read_csv("./프로젝트2주차/data_week2.csv", encoding='cp949')
# 'date_time' 열을 datetime 형식으로 변환
data_df['date_time'] = pd.to_datetime(data_df['date_time'], format='%Y-%m-%d %H', errors='coerce')

# 마지막 하루의 날짜 확인
last_day = data_df['date_time'].dt.date.max()

# train 데이터: 마지막 하루 제외한 데이터
train_data = data_df[data_df['date_time'].dt.date != last_day]

# test 데이터: 마지막 하루의 데이터
test_data = data_df[data_df['date_time'].dt.date == last_day]

# 각각의 데이터 개수 확인
train_count = train_data.shape[0]
test_count = test_data.shape[0]

train_count, test_count

data_df.shape

# ------------------------


# 원본 Data
df_raw = df.copy()
df_raw
#-------------------------------------------------------------------------

# 데이터 파악하기

df.head()
df.info()
df.describe()

#-------------------------------------------------------------------------

# 'Malgun Gothic' 폰트로 설정
plt.rc('font', family='Malgun Gothic')

# 마이너스 기호가 제대로 표시되도록 설정
mpl.rcParams['axes.unicode_minus'] = False

# 숫자형 변수 선택
quantitative_value = df.select_dtypes(include=['float64', 'int64']).columns

# 서브플롯 생성
fig, axes = plt.subplots(nrows=3, ncols=3, figsize=(15, 12))
fig.suptitle('Box-Plot', fontsize=16)

# 서브플롯에 각 변수의 박스플롯 그리기
axes = axes.flatten()
for i, column in enumerate(quantitative_value):
    axes[i].boxplot(df[column].dropna())
    axes[i].set_title(column)
    axes[i].set_xlabel('')
    axes[i].set_ylabel('값')

# 남은 서브플롯 제거 (만약 숫자형 변수가 서브플롯 수보다 적을 경우)
for j in range(i + 1, len(axes)):
    fig.delaxes(axes[j])

# 레이아웃 조정
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

#-------------------------------------------------------------------------

# 숫자형 변수들 간의 상관관계 계산
corr_matrix = df[quantitative_value].corr()

# 히트맵 생성
plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm', linewidths=0.5)
plt.title('변수들 간의 상관관계 히트맵')
plt.show()

#-------------------------------------------------------------------------
# 변수 설정

# 날짜 및 시간 형식 변환
# object type datetime으로 바꾸기
df['date_time'] = pd.to_datetime(df['date_time'], format='%Y-%m-%d %H')

# 요일 정보를 문자열로 추가
df['요일'] = df['date_time'].dt.day_name()

# 공휴일 목록 (6월 6일, 8월 15일 토요일 8월 17일 월요일)
holidays = ['2020-06-06', '2020-08-15','2020-08-17']

# 공휴일이면 1, 아니면 0을 표시하는 열 추가 
df['공휴일'] = df['date_time'].dt.strftime('%Y-%m-%d').isin(holidays).astype(object)

# 불쾌지수 계산하는 열 추가
df['불쾌지수'] = 0.81 * df['기온(°C)'] + 0.01 * df['습도(%)'] * (0.99 * df['기온(°C)'] - 14.3) + 46.3

# 불쾌지수 등급을 매기는 함수 정의
def discomfort_index_level(discomfort_index):
    if discomfort_index >= 80:
        return 4
    elif discomfort_index >= 75:
        return 3
    elif discomfort_index >= 68:
        return 2
    else:
        return 1

# 불쾌지수 등급을 계산하여 새로운 열 추가
df['불쾌지수_등급'] = df['불쾌지수'].apply(discomfort_index_level)
df['불쾌지수_등급'] = df['불쾌지수_등급'].astype(object)

# 체감 온도
df['체감온도'] = 13.12 + 0.6215 * df['기온(°C)'] - 11.37 * (df['풍속(m/s)'] ** 0.16) + 0.3965 * (df['풍속(m/s)'] ** 0.16) * df['기온(°C)']

# 시간대 구분 함수 정의
def time_period(date_time):
    hour = date_time.hour
    if 0 <= hour <= 5:
        return '새벽'
    elif 6 <= hour <= 11:
        return '아침'
    elif 12 <= hour <= 17:
        return '낮'
    else:
        return '저녁'

# 시간대에 따라 새로운 열 '시간대' 추가 
df['시간대'] = df['date_time'].apply(time_period)

# 강수량이 0보다 크면 1, 그렇지 않으면 0 
df['강수여부'] = df['강수량(mm)'].apply(lambda x: 1 if x > 0 else 0)

# 각 num별로 그룹화하여 전력 변화율 계산
df['전력변화율'] = df.groupby('num')['전력사용량(kWh)'].pct_change() * 100 

# NaN 값을 0으로 채워서 첫 번째 row에 변화율을 0으로 설정
df['전력변화율'] = df['전력변화율'].fillna(0)

df["전력변화율"].isna().sum()
# 변수명 변경
df = df.rename(columns={
    '전력사용량(kWh)': 'power',
    '기온(°C)': 'temp',
    '풍속(m/s)': 'wind',
    '습도(%)': 'hum',
    '강수량(mm)': 'rain',
    '일조(hr)': 'sun',
    '비전기냉방설비운영': 'non_elec',
    '태양광보유': 'solar',
    '요일': 'weekday',
    '공휴일': 'holiday',
    '불쾌지수': 'di',
    '불쾌지수_등급': 'di_level',
    '체감온도': 'human_temp',
    '시간대': 'time_period',
    '강수여부': 'rain_check',
    '전력변화율': 'power_rate'
})


# object 변환
df['non_elec'] = df['non_elec'].astype(object)
df['solar'] = df['solar'].astype(object)
df['weekday'] = df['weekday'].astype(object)
df['rain_check'] = df['rain_check'].astype(object)

df.info()

# Fourier Features
df['sin_hour_1'] = np.sin(2 * np.pi * df['date_time'].dt.hour/24.0)
df['cos_hour_1'] = np.cos(2 * np.pi * df['date_time'].dt.hour/24.0)

# 원형 시각화
import matplotlib.pyplot as plt

plt.figure(figsize=(6, 6))
plt.plot(df['sin_hour_1'], df['cos_hour_1'], 'o-')
plt.title('Circular Representation of Hourly Fourier Features')
plt.ylabel('cos(hour)')
plt.xlabel('sin(hour)')
plt.axhline(0, color='black', linewidth=0.5, linestyle='--')
plt.axvline(0, color='black', linewidth=0.5, linestyle='--')
plt.grid(True)
plt.show()

#-------------------------------------------------------------------------

# Box-Plot
plt.figure(figsize=(12, 8))
sns.boxplot(data=df[['power', 'temp', 'wind', 'hum', 
                     'rain', 'sun', 'di', 'human_temp', 
                     'power_rate']])
plt.title('Boxplot of Selected Variables')
plt.xlabel('Variables')
plt.ylabel('Values')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()

#-------------------------------------------------------------------------

# 수치형 변수 선택
numeric_vars = ['power','temp', 'wind', 'hum', 'rain', 
                'sun', 'di', 'human_temp', 'power_rate']

# 상관관계 계산
corr_matrix_excluding_power = df[numeric_vars].corr()

# 히트맵 시각화
plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix_excluding_power, annot=True, cmap='coolwarm', linewidths=0.5, linecolor='black', cbar=True)
plt.title('Correlation Heatmap')
plt.show()

#-------------------------------------------------------------------------

# 시간별 전력 사용량 평균 계산 (시간 단위로 그룹화)
df['hour'] = df['date_time'].dt.hour
hourly_avg_usage = df.groupby('hour')['power'].mean()

# 시각화
plt.figure(figsize=(10, 6))
plt.plot(hourly_avg_usage.index, hourly_avg_usage.values, marker='o', linestyle='-', color='blue')
plt.xlabel('시간 (Hour)')
plt.ylabel('평균 전력 사용량 (kWh)')
plt.title('시간별 평균 전력 사용량 변화')
plt.grid(True)
plt.xticks(range(0, 24))  # 0시부터 23시까지 표시
plt.show()

#-------------------------------------------------------------------------

# 서브플롯의 형태를 (10, 6)으로 변경하여 시각화
fig, axs = plt.subplots(10, 6, figsize=(20, 30), sharex=True, sharey=True)
fig.suptitle('건물별 시간대별 평균 전력 사용량 변화', fontsize=24)

# 각 건물에 대해 서브플롯에 그래프 그리기

building_numbers = df['num'].unique()

for idx, building in enumerate(building_numbers):
    row = idx // 6
    col = idx % 6
    building_data = df[df['num'] == building]
    hourly_avg_usage = building_data.groupby('hour')['power'].mean()
    axs[row, col].plot(hourly_avg_usage.index, hourly_avg_usage.values, marker='o', linestyle='-', color='blue')
    axs[row, col].set_title(f'건물 {building}', fontsize=12)
    axs[row, col].grid(True)

# 공통 x, y축 레이블 설정
plt.setp(axs[-1, :], xlabel='시간 (Hour)')
plt.setp(axs[:, 0], ylabel='평균 전력 사용량 (kWh)')

# 레이아웃 조정
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

#-------------------------------------------------------------------------

from sklearn.preprocessing import MinMaxScaler, StandardScaler
import numpy as np

# 스케일러 객체 생성
min_max_scaler = MinMaxScaler()
standard_scaler = StandardScaler()

df.info()

# 무한대 값에 대해 0으로 대응
df.replace([np.inf, -np.inf], 0, inplace=True)


# 각 변수에 대해 Scaling 하고, scaled_df로 새로운 데이터 프레임 생성
# 기존 데이터프레임의 원래 변수들을 포함한 scaled_df 생성

from sklearn.preprocessing import PowerTransformer

# Yeo-Johnson 변환기 생성
yeo_transformer = PowerTransformer(method='yeo-johnson')


scaled_df = pd.DataFrame({
    'num': df['num'],
    'date_time': df['date_time'],
    'weekday' : df['weekday'],
    'holiday' : df['holiday'],
    'di_level' : df['di_level'],
    'non_elec': df['non_elec'],
    'solar': df['solar'],
    'time_period' : df['time_period'],
    'rain_check' : df['rain_check'],
    'hour' : df['hour'],
    'power': df['power'],
    'temp': df['temp'],
    'wind_scaled': yeo_transformer.fit_transform(df[['wind']]).flatten(),
    'hum_scaled': yeo_transformer.fit_transform(df[['hum']]).flatten(),
    'sun_scaled': yeo_transformer.fit_transform(df[['sun']]).flatten(),
    'di_scaled': yeo_transformer.fit_transform(df[['di']]).flatten(),
    'human_temp_scaled': yeo_transformer.fit_transform(df[['human_temp']]).flatten(),
    'rain_scaled': yeo_transformer.fit_transform(df[['rain']]).flatten(),
    'power_rate_scaled': yeo_transformer.fit_transform(df[['power_rate']]).flatten(),
    'sin_hour_1' : df['sin_hour_1'],
    'cos_hour_1' : df['cos_hour_1']
})


# wind 변환된 데이터 시각화 (히스토그램)
plt.figure(figsize=(8, 6))
plt.hist(df['wind'],  bins=30, color='red', edgecolor='black', alpha=0.5)
plt.hist(scaled_df['wind_scaled'], bins=30, color='skyblue', edgecolor='black', alpha=0.5)
plt.title('Distribution of Transformed Wind (Yeo-Johnson)')
plt.xlabel('Transformed Wind')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# hum 변환된 데이터 시각화 (히스토그램)
plt.figure(figsize=(8, 6))
plt.hist(df['hum'],  bins=30, color='red', edgecolor='black', alpha=0.5)
plt.hist(scaled_df['hum_scaled'], bins=30, color='skyblue', edgecolor='black', alpha=0.5)
plt.title('Distribution of Transformed Wind (Yeo-Johnson)')
plt.xlabel('Transformed Wind')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# 왜도와 첨도 계산
df['hum'].skew()
df['hum'].kurtosis()

scaled_df['hum_scaled'].skew()
scaled_df['hum_scaled'].kurtosis()

# sun 변환된 데이터 시각화 (히스토그램)
plt.figure(figsize=(8, 6))
plt.hist(df['sun'],  bins=30, color='red', edgecolor='black', alpha=0.5)
plt.hist(scaled_df['sun_scaled'], bins=30, color='skyblue', edgecolor='black', alpha=0.5)
plt.title('Distribution of Transformed Wind (Yeo-Johnson)')
plt.xlabel('Transformed Wind')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# 왜도와 첨도 계산
df['sun'].skew()
df['sun'].kurtosis()

scaled_df['sun_scaled'].skew()
scaled_df['sun_scaled'].kurtosis()

# di 변환된 데이터 시각화 (히스토그램)
plt.figure(figsize=(8, 6))
plt.hist(df['di'],  bins=30, color='red', edgecolor='black', alpha=0.5)
plt.hist(scaled_df['di_scaled'], bins=30, color='skyblue', edgecolor='black', alpha=0.5)
plt.title('Distribution of Transformed Wind (Yeo-Johnson)')
plt.xlabel('Transformed Wind')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# 왜도와 첨도 계산
df['di'].skew()
df['di'].kurtosis()

scaled_df['di_scaled'].skew()
scaled_df['di_scaled'].kurtosis()

# human_temp 변환된 데이터 시각화 (히스토그램)
plt.figure(figsize=(8, 6))
plt.hist(df['human_temp'],  bins=30, color='red', edgecolor='black', alpha=0.5)
plt.hist(scaled_df['human_temp_scaled'], bins=30, color='skyblue', edgecolor='black', alpha=0.5)
plt.title('Distribution of Transformed Wind (Yeo-Johnson)')
plt.xlabel('Transformed Wind')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# 왜도와 첨도 계산
df['human_temp'].skew()
df['human_temp'].kurtosis()

scaled_df['human_temp_scaled'].skew()
scaled_df['human_temp_scaled'].kurtosis()


# rain 변환된 데이터 시각화 (히스토그램)
plt.figure(figsize=(8, 6))
plt.hist(df['rain'],  bins=30, color='red', edgecolor='black', alpha=0.5)
plt.hist(scaled_df['rain_scaled'], bins=30, color='skyblue', edgecolor='black', alpha=0.5)
plt.title('Distribution of Transformed Wind (Yeo-Johnson)')
plt.xlabel('Transformed Wind')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# 왜도와 첨도 계산
df['rain'].skew()
df['rain'].kurtosis()

scaled_df['rain_scaled'].skew()
scaled_df['rain_scaled'].kurtosis()

# power_rate 변환된 데이터 시각화 (히스토그램)
plt.figure(figsize=(8, 6))
plt.hist(df['power_rate'],  bins=30, color='red', edgecolor='black', alpha=0.5)
plt.hist(scaled_df['power_rate_scaled'], bins=30, color='skyblue', edgecolor='black')
plt.title('Distribution of Transformed Wind (Yeo-Johnson)')
plt.xlabel('Transformed Wind')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# 왜도와 첨도 계산
df['power_rate'].skew()
df['power_rate'].kurtosis()

scaled_df['power_rate_scaled'].skew()
scaled_df['power_rate_scaled'].kurtosis()


#---------------------------------------------------------------------------------------

# 스케일 진행
scaled_df

# 스케일 X
df = df.drop(columns='hour')

scaled_df.info()
df.info()

# ---------------------------------------------------------------------------------------

from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# 전력 사용량 패턴 분석을 위해 필요한 열만 선택
# 시간대별 평균 전력 사용량을 계산하여 K-평균 군집화에 사용할 데이터셋 생성
df['date_time'] = pd.to_datetime(df['date_time'], format='%Y-%m-%d %H')
df['hour'] = df['date_time'].dt.hour

# 시간대별 평균 전력 사용량을 구하여 피벗 테이블 생성
pivot_df = df.pivot_table(index='num', columns='hour', values='power', aggfunc=np.mean).fillna(0)

# K-평균 군집화를 수행할 때 최적의 군집 수를 찾기 위해 엘보우(Elbow) 방법 사용
inertia = []
k_range = range(1, 11)

for k in k_range:
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(pivot_df)
    inertia.append(kmeans.inertia_)

# 엘보우 차트 시각화
plt.figure(figsize=(10, 6))
plt.plot(k_range, inertia, marker='o')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Inertia')
plt.title('Elbow Method for Optimal k')
plt.grid(True)
plt.show()

#----------------------PCA 그림---------------------------------------------------

# 필요한 라이브러리 호출
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

# 시간대별 평균 전력 사용량으로 그룹화
grouped_data = df.groupby(['num', df['date_time'].dt.hour])['power'].mean().unstack()

# KMeans 클러스터링 수행
kmeans = KMeans(n_clusters=4, random_state=0)
clusters = kmeans.fit_predict(pivot_df)

# PCA를 사용해 2차원으로 차원 축소
pca = PCA(n_components=2)
pca_components = pca.fit_transform(pivot_df)

# 클러스터링 결과를 시각화
plt.figure(figsize=(10, 8))
for cluster in np.unique(clusters):
    plt.scatter(pca_components[clusters == cluster, 0], 
                pca_components[clusters == cluster, 1], 
                label=f'Cluster {cluster}')

# 클러스터 중심 표시
centers = kmeans.cluster_centers_
centers_pca = pca.transform(centers)
plt.scatter(centers_pca[:, 0], centers_pca[:, 1], s=300, c='red', marker='X', label='Centroids')

plt.title('KMeans Clustering Visualization (PCA Reduced)')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.legend()
plt.grid(True)
plt.show()

#-------------------------------------------------------------------------

# 시간대별 평균 전력 사용량으로 그룹화
grouped_data = df.groupby(['num', df['date_time'].dt.hour])['power'].mean().unstack()

# KMeans 클러스터링 수행 (4개의 클러스터)
kmeans = KMeans(n_clusters=4, random_state=0)
building_clusters = kmeans.fit_predict(grouped_data)

# 클러스터 레이블을 데이터프레임에 추가
grouped_data['cluster'] = building_clusters

# 클러스터별 데이터프레임 분할
building_0 = grouped_data[grouped_data['cluster'] == 0]
building_1 = grouped_data[grouped_data['cluster'] == 1]
building_2 = grouped_data[grouped_data['cluster'] == 2]
building_3 = grouped_data[grouped_data['cluster'] == 3]

# grouped_data에서 클러스터 정보만 추출
cluster_data = grouped_data[['cluster']].reset_index()

# 기존 df에 'num'을 기준으로 cluster 레이블 추가 (병합)
df = pd.merge(df, cluster_data[['num', 'cluster']], on='num', how='left')
df

df['cluster'] = df['cluster'].astype('object')

#-------------------------------------------------------------------------
# scaled_df에 클러스터 레이블 추가 (num을 기준으로 병합)

# 시간대별 평균 전력 사용량으로 그룹화
grouped_data = df.groupby(['num', scaled_df['date_time'].dt.hour])['power'].mean().unstack()

# KMeans 클러스터링 수행 (4개의 클러스터)
kmeans = KMeans(n_clusters=4, random_state=0)
building_clusters = kmeans.fit_predict(grouped_data)

# 클러스터 레이블을 데이터프레임에 추가
grouped_data['cluster'] = building_clusters

# 클러스터별 데이터프레임 분할
building_0 = grouped_data[grouped_data['cluster'] == 0]
building_1 = grouped_data[grouped_data['cluster'] == 1]
building_2 = grouped_data[grouped_data['cluster'] == 2]
building_3 = grouped_data[grouped_data['cluster'] == 3]

# grouped_data에서 클러스터 정보만 추출
cluster_data = grouped_data[['cluster']].reset_index()

# 기존 df에 'num'을 기준으로 cluster 레이블 추가 (병합)
scaled_df = pd.merge(scaled_df, cluster_data[['num', 'cluster']], on='num', how='left')
scaled_df

scaled_df['cluster'] = scaled_df['cluster'].astype('object')

df.info()
scaled_df.info()

# df_raw

# 클러스터링을 위한 필요한 열 선택 (숫자형 변수만 선택)
numeric_columns = df_raw.select_dtypes(include=['float64', 'int64']).columns
df_raw_numeric = df_raw[numeric_columns]

# KMeans 클러스터링 수행 (클러스터 수는 4로 설정)
kmeans = KMeans(n_clusters=4, random_state=42)
df_raw['cluster'] = kmeans.fit_predict(df_raw_numeric)

# 클러스터 결과를 확인
print(df_raw[['cluster']].head())
df_raw

#------------------- 건물 클러스터별 색상 시각화 ------------------------

# 클러스터 별로 다른 색상으로 건물별 시간대별 평균 전력 사용량 변화를 시각화하는 코드
import matplotlib.pyplot as plt

# 서브플롯의 형태를 (10, 6)으로 변경하여 시각화
fig, axs = plt.subplots(10, 6, figsize=(20, 30), sharex=True, sharey=True)
fig.suptitle('클러스터별 건물 시간대별 평균 전력 사용량 변화', fontsize=24)

# 클러스터에 따른 색상 지정
cluster_colors = ['green', 'red', 'gray', 'orange']

building_numbers = df['num'].unique()

for idx, building in enumerate(building_numbers):
    row = idx // 6
    col = idx % 6
    building_data = df[df['num'] == building]
    hourly_avg_usage = building_data.groupby('hour')['power'].mean()
    
    # 해당 건물의 클러스터 정보 가져오기
    cluster_label = df[df['num'] == building]['cluster'].iloc[0]
    color = cluster_colors[cluster_label]
    
    axs[row, col].plot(hourly_avg_usage.index, hourly_avg_usage.values, marker='o', linestyle='-', color=color)
    axs[row, col].set_title(f'건물 {building} (클러스터 {cluster_label})', fontsize=12)
    axs[row, col].grid(True)

# 공통 x, y축 레이블 설정
plt.setp(axs[-1, :], xlabel='시간 (Hour)')
plt.setp(axs[:, 0], ylabel='평균 전력 사용량 (kWh)')

# 레이아웃 조정
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

#-------------------------------------------------------------------------
# cluster 1, 2, 3, 4 : train / test data 분리

# 2020년 8월 24일의 데이터만 테스트 데이터로 분리(df_raw, df, scaled_df에 대해 대응)
# df_raw_test_train
# 'date_time' 열을 datetime 형식으로 변환
df_raw['date_time'] = pd.to_datetime(df_raw['date_time'], format='%Y-%m-%d %H')
df_raw_test = df_raw[df_raw['date_time'].dt.date == pd.to_datetime('2020-08-24').date()]
df_raw_train = df_raw[df_raw['date_time'].dt.date != pd.to_datetime('2020-08-24').date()]
df_raw['date_time'] = df_raw['date_time'].astype(object)
df_raw_test['date_time'] = df_raw_test['date_time'].astype(object)
df_raw_train['date_time'] = df_raw_train['date_time'].astype(object)
df_raw.info()

# y: 전력사용량(kWh) (목표 변수)
df_raw_test_y = df_raw_test['전력사용량(kWh)']
# X: 나머지 특성 (입력 변수)
df_raw_test_x = df_raw_test.drop(columns=['전력사용량(kWh)']) 
# y: 전력사용량(kWh) (목표 변수)
df_raw_train_y = df_raw_train['전력사용량(kWh)']
# X: 나머지 특성 (입력 변수)
df_raw_train_x = df_raw_train.drop(columns=['전력사용량(kWh)']) 


# df_test_train
df_test = df[df['date_time'].dt.date == pd.to_datetime('2020-08-24').date()]
df_train = df[df['date_time'].dt.date != pd.to_datetime('2020-08-24').date()]

# y: power (목표 변수)
df_test_y = df_test['power']
# X: 나머지 특성 (입력 변수)
df_test_x = df_test.drop(columns=['power']) 
# y: power (목표 변수)
df_train_y = df_train['power']
# X: 나머지 특성 (입력 변수)
df_train_x = df_train.drop(columns=['power']) 

# scaled_test_train
scaled_df_test = scaled_df[scaled_df['date_time'].dt.date == pd.to_datetime('2020-08-24').date()]
scaled_df_train = scaled_df[scaled_df['date_time'].dt.date != pd.to_datetime('2020-08-24').date()]

# y: power (목표 변수)
scaled_df_test_y = scaled_df_test['power']
# X: 나머지 특성 (입력 변수)
scaled_df_test_x = scaled_df_test.drop(columns=['power']) 
# y: power (목표 변수)
scaled_df_train_y = scaled_df_train['power']
# X: 나머지 특성 (입력 변수)
scaled_df_train_x = scaled_df_train.drop(columns=['power'])

#-------------------------------------------------------------------------
# 왜도 & 첨도 Code
# 똑같은 코드에 변수들 바꿔서 넣으면서 그래프 뽑음

# 히스토그램에 왜도와 첨도를 표시하는 코드
plt.figure(figsize=(8, 6))

# 원본 데이터 히스토그램
plt.hist(df['hum'], bins=30, color='red', edgecolor='black', alpha=0.5, label='Original Humidity')
# 변환된 데이터 히스토그램
plt.hist(scaled_df['hum_scaled'], bins=30, color='blue', edgecolor='black', alpha=0.5, label='Transformed Humidity')

# 왜도와 첨도 계산 (원본 데이터)
orig_skewness = df['hum'].skew()
orig_kurtosis = df['hum'].kurtosis()

# 왜도와 첨도 계산 (변환된 데이터)
trans_skewness = scaled_df['hum_scaled'].skew()
trans_kurtosis = scaled_df['hum_scaled'].kurtosis()

# 히스토그램에 텍스트 추가 (왜도와 첨도), 그래프 상단에 위치
plt.annotate(f"Original: Skewness = {orig_skewness:.2f}, Kurtosis = {orig_kurtosis:.2f}", 
             xy=(0.5, -0.15), xycoords='axes fraction', color='red', fontsize=12, ha='center')

plt.annotate(f"Transformed: Skewness = {trans_skewness:.2f}, Kurtosis = {trans_kurtosis:.2f}", 
             xy=(0.5, -0.2), xycoords='axes fraction', color='blue', fontsize=12, ha='center')

# 기타 설정
plt.title('Distribution of Humidity: Original vs Transformed (Yeo-Johnson)')
plt.xlabel('Humidity')
plt.ylabel('Frequency')
plt.grid(True)
plt.legend()

#-------------------------------------------------------------------------
# LSTM를 가지고 놀아보자 (woong)
#-------------------------------------------------------------------------
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler

# SMAPE 계산 함수 정의
def smape(y_true, y_pred):
    return 100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred)))

# MAPE 계산 함수 정의
def mape(y_true, y_pred):
    return 100 * np.mean(np.abs((y_true - y_pred) / y_true))

# 시퀀스 생성 함수 정의
def create_sequences(data, sequence_length):
    X, y = [], []
    for i in range(len(data) - sequence_length):
        X.append(data[i:i + sequence_length])
        y.append(data[i + sequence_length])
    return np.array(X), np.array(y)

# LSTM 모델 학습 및 평가 함수 정의
def run_lstm_for_buildings(df, target_column, sequence_length=24):
    smape_scores = []
    mape_scores = []
    buildings = df['num'].unique()  # 건물 번호 리스트

    for building in buildings:
        building_data = df[df['num'] == building].sort_values('date_time')

        # 데이터 정규화
        scaler = MinMaxScaler()
        scaled_data = scaler.fit_transform(building_data[[target_column]])

        # 시퀀스 데이터 생성
        X, y = create_sequences(scaled_data, sequence_length)

        # Train/Test 데이터 분리
        train_size = int(len(X) * 0.8)
        X_train, X_test = X[:train_size], X[train_size:]
        y_train, y_test = y[:train_size], y[train_size:]

        # LSTM 모델 정의
        model = tf.keras.Sequential([
            tf.keras.layers.LSTM(64, input_shape=(sequence_length, 1)),
            tf.keras.layers.Dense(1)
        ])
        model.compile(optimizer='adam', loss='mse')

        # 모델 학습
        model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=0)

        # 예측 수행
        y_pred = model.predict(X_test)

        # 예측 값 역정규화
        y_pred_rescaled = scaler.inverse_transform(y_pred)
        y_test_rescaled = scaler.inverse_transform(y_test.reshape(-1, 1))

        # SMAPE 및 MAPE 계산
        smape_score = smape(y_test_rescaled, y_pred_rescaled)
        mape_score = mape(y_test_rescaled, y_pred_rescaled)

        smape_scores.append({'Building': building, 'SMAPE': smape_score})
        mape_scores.append({'Building': building, 'MAPE': mape_score})

    return pd.DataFrame(smape_scores), pd.DataFrame(mape_scores)

# df, df_raw, scaled_df에 대한 LSTM 예측 및 SMAPE/MAPE 계산
def evaluate_all_buildings(df_raw, df, scaled_df, sequence_length=24):
    print("\nLSTM 예측 및 SMAPE/MAPE 계산: df_raw")
    smape_df_raw, mape_df_raw = run_lstm_for_buildings(df_raw, target_column='전력사용량(kWh)', sequence_length=sequence_length)
    
    print("\nLSTM 예측 및 SMAPE/MAPE 계산: df")
    smape_df, mape_df = run_lstm_for_buildings(df, target_column='power', sequence_length=sequence_length)
    
    print("\nLSTM 예측 및 SMAPE/MAPE 계산: scaled_df")
    smape_scaled_df, mape_scaled_df = run_lstm_for_buildings(scaled_df, target_column='power', sequence_length=sequence_length)

    return smape_df_raw, mape_df_raw, smape_df, mape_df, smape_scaled_df, mape_scaled_df

# 실행
smape_df_raw, mape_df_raw, smape_df, mape_df, smape_scaled_df, mape_scaled_df = evaluate_all_buildings(df_raw, df, scaled_df)

# 결과 데이터프레임 출력
print("\ndf_raw SMAPE 결과:\n", smape_df_raw)
print("\ndf_raw MAPE 결과:\n", mape_df_raw)

print("\ndf SMAPE 결과:\n", smape_df)
print("\ndf MAPE 결과:\n", mape_df)

print("\nscaled_df SMAPE 결과:\n", smape_scaled_df)
print("\nscaled_df MAPE 결과:\n", mape_scaled_df)


# ------------------------------------------------------------
# SARIMA -----------------------------------------------------------------

import statsmodels.api as sm
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# SMAPE 계산 함수 정의
def smape(y_true, y_pred):
    return 100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred)))

# 각 건물별 SARIMA 모델 학습 및 예측 함수
def sarima_building_analysis(df, building_column, target_col, cluster_col):
    buildings = df[building_column].unique()
    smape_scores = []
    
    for building in buildings:
        cluster_label = df[df[building_column] == building][cluster_col].iloc[0]  # 클러스터 정보 가져오기
        print(f"건물 {building} (클러스터 {cluster_label}) 모델 학습 중...")
        
        # 각 건물 데이터 필터링
        building_data = df[df[building_column] == building]
        
        # 'date_time'을 인덱스로 설정하고, target_col 선택
        building_data = building_data.set_index('date_time')
        building_data.index = pd.to_datetime(building_data.index)
        building_data = building_data.sort_index()  # 인덱스를 정렬
        
        y = building_data[target_col]
        
        # 마지막 날을 테스트 데이터로 분리
        last_day = y.index[-1].date()
        train_data = y[y.index.date != last_day]
        test_data = y[y.index.date == last_day]
        
        # SARIMA 모델 파라미터 설정 (기본 설정, 필요시 최적화)
        p, d, q = 1, 1, 1  # ARIMA 파라미터
        P, D, Q, s = 1, 1, 1, 24  # 계절성 파라미터 (일간 계절성 가정)
        
        try:
            # SARIMA 모델 학습
            model = sm.tsa.SARIMAX(train_data, order=(p, d, q), seasonal_order=(P, D, Q, s), enforce_stationarity=False, enforce_invertibility=False)
            result = model.fit(disp=False)
            
            # 테스트 데이터에 대한 예측
            forecast = result.predict(start=test_data.index[0], end=test_data.index[-1])
            
            # SMAPE 계산
            score = smape(test_data.values, forecast.values)
            smape_scores.append({'Building': building, 'Cluster': cluster_label, 'SMAPE': score, 'DataFrame': df.name})
            
            # 마지막 1주일 데이터만 시각화
            plt.figure(figsize=(10, 6))
            plt.plot(train_data[-24*7:], label='Train Data')
            plt.plot(test_data, label='Test Data', color='orange')
            plt.plot(forecast, label='Forecast', linestyle='--', color='red')
            plt.title(f'건물 {building} (클러스터 {cluster_label}) 전력 사용량 예측 및 SMAPE: {score:.2f}')
            plt.xlabel('Date Time')
            plt.ylabel('Power Consumption (kWh)')
            plt.legend()
            plt.grid(True)
            plt.show()
            
        except Exception as e:
            print(f"건물 {building} 모델 학습 실패: {e}")
    
    # 결과를 데이터프레임으로 변환
    smape_df = pd.DataFrame(smape_scores)
    return smape_df

# 각 데이터프레임의 이름 설정 (시각화 및 결과 저장 시 구분용)
df_raw.name = 'df_raw'
scaled_df.name = 'scaled_df'
df.name = 'df'

# 각 데이터프레임에 대해 SARIMA 모델 적용
print("raw_df에 SARIMA 적용")
smape_raw_df = sarima_building_analysis(df_raw, 'num', '전력사용량(kWh)', 'cluster')

print("scaled_df에 SARIMA 적용")
smape_scaled_df = sarima_building_analysis(scaled_df, 'num', 'power', 'cluster')

print("df에 SARIMA 적용")
smape_df_df = sarima_building_analysis(df, 'num', 'power', 'cluster')

# 세 결과를 하나의 데이터프레임으로 결합
final_smape_df = pd.concat([smape_raw_df, smape_scaled_df, smape_df_df], ignore_index=True)


def reorganize_smape_data(smape_raw_df, smape_scaled_df, smape_df_df):
    # 건물 번호를 기준으로 데이터프레임 병합
    merged_df = pd.DataFrame({'Building': smape_raw_df['Building']})
    
    # 각 데이터프레임의 SMAPE 값을 열로 추가
    merged_df['SARIMA_raw_df'] = smape_raw_df['SMAPE'].values
    merged_df['SARIMA_scaled_df'] = smape_scaled_df['SMAPE'].values
    merged_df['SARIMA_df'] = smape_df_df['SMAPE'].values
    
    return merged_df

# SMAPE 데이터를 재구성하여 병합
final_merged_smape_df_SARIMA = reorganize_smape_data(smape_raw_df, smape_scaled_df, smape_df_df)

# final_merged_smape_df_SARIMA.to_csv('./data/final_merged_smape_df_SARIMA.csv', index=False)

#-------------------------------------------------------------------------
# 건물별로 Prophet 적용
#-------------------------------------------------------------------------

from prophet import Prophet 

# SMAPE 계산 함수 정의
def smape(y_true, y_pred):
    return 100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred)))

# MAPE 계산 함수 정의
def mape(y_true, y_pred):
    return 100 * np.mean(np.abs((y_true - y_pred) / y_true))

# Prophet 모델 학습 및 시각화 함수 정의
def run_prophet_model_viz_last_day(df, target_col, date_col='date_time', building_col='num', test_date='2020-08-24', dataframe_name=''):
    # 건물 데이터 필터링
    building_data = df.copy()
    
    # 날짜 열을 datetime 형식으로 변환
    building_data[date_col] = pd.to_datetime(building_data[date_col])
    
    # 날짜 및 타겟 변수를 Prophet 형식에 맞게 준비
    building_data = building_data.rename(columns={date_col: 'ds', target_col: 'y'})
    
    # 데이터프레임에 존재하는 범주형 변수만 선택
    possible_categorical_vars = ['weekday', 'time_period', 'holiday']
    categorical_vars = [var for var in possible_categorical_vars if var in building_data.columns]
    
    # 범주형 변수가 존재하는 경우 원-핫 인코딩
    if categorical_vars:
        building_data = pd.get_dummies(building_data, columns=categorical_vars, drop_first=True)
    
    # 테스트 데이터와 학습 데이터를 분리
    train_data = building_data[building_data['ds'] < pd.to_datetime(test_date)]
    test_data = building_data[building_data['ds'].dt.date == pd.to_datetime(test_date).date()]
    
    # 외생 변수 처리
    exog_vars = [col for col in building_data.columns if col not in ['ds', 'y', building_col]]
    
    # Prophet 모델 정의
    model = Prophet(daily_seasonality=True)
    
    # 외생 변수 추가
    for var in exog_vars:
        model.add_regressor(var)
    
    # 모델 학습
    model.fit(train_data[['ds', 'y'] + exog_vars])
    
    # 예측 수행 (테스트 데이터 기간)
    future = test_data[['ds'] + exog_vars]
    forecast = model.predict(future)
    
    # SMAPE 계산
    smape_score = smape(test_data['y'].values, forecast['yhat'].values)
    
    # MAPE 계산
    mape_score = mape(test_data['y'].values, forecast['yhat'].values)
    
    # 마지막 1주일 데이터와 예측한 하루 시각화
    last_week_start = pd.to_datetime(test_date) - pd.Timedelta(days=7)
    plt.figure(figsize=(12, 6))
    plt.plot(train_data['ds'][train_data['ds'] >= last_week_start], train_data['y'][train_data['ds'] >= last_week_start], label='Train Data', color='blue')
    plt.plot(test_data['ds'], test_data['y'], label='Test Data', color='orange', linestyle='-')
    plt.plot(forecast['ds'], forecast['yhat'], label='Forecast', color='red', linestyle='--')
    
    # 제목에 데이터프레임 이름, MAPE와 건물 num 추가
    building_number = building_data[building_col].unique()[0]  # 유일한 건물 번호 가져오기
    plt.title(f"{dataframe_name} (건물 {building_number}) - Prophet 전력 사용량 예측 - 마지막 하루, SMAPE = {smape_score:.5f}%, MAPE = {mape_score:.5f}%")
    
    plt.xlabel("Date Time")
    plt.ylabel("Power Consumption (kWh)")
    plt.legend()
    plt.grid(True)
    plt.show()
    
    # SMAPE 출력
    print(f"건물 {building_number}에 대한 SMAPE: {smape_score:.5f}%")
    
    # MAPE 출력
    print(f"건물 {building_number}에 대한 MAPE: {mape_score:.5f}%")
    
    return smape_score, mape_score

# 1번부터 60번 건물까지 반복
for building_num in range(1, 61):
    print(f"\ndf_raw에 대한 Prophet 학습 및 예측 (건물 {building_num})")
    smape_raw, mape_raw = run_prophet_model_viz_last_day(
        df_raw[df_raw['num'] == building_num], 
        target_col='전력사용량(kWh)', 
        building_col='num',
        dataframe_name='df_raw'
    )

    print(f"\ndf에 대한 Prophet 학습 및 예측 (건물 {building_num})")
    smape_df, mape_df = run_prophet_model_viz_last_day(
        df[df['num'] == building_num], 
        target_col='power', 
        building_col='num',
        dataframe_name='df'
    )

    print(f"\nscaled_df에 대한 Prophet 학습 및 예측 (건물 {building_num})")
    smape_scaled_df, mape_scaled_df = run_prophet_model_viz_last_day(
        scaled_df[scaled_df['num'] == building_num], 
        target_col='power', 
        building_col='num',
        dataframe_name='scaled_df'
    )

# ---------------------Prophet_SMAPE 결과 CSV로 저장--------------------------------

import pandas as pd

# 결과를 저장할 빈 데이터프레임 생성
results = pd.DataFrame(columns=['num', 'df_raw', 'df', 'scaled_df'])

# 1번 건물부터 60번 건물까지 반복
for building_num in range(1, 61):
    # raw_df에 대한 Prophet 모델 학습 및 예측
    smape_raw, mape_raw = run_prophet_model_viz_last_day(df_raw[df_raw['num'] == building_num], 
                                                           target_col='전력사용량(kWh)', 
                                                           building_col='num')

    # df에 대한 Prophet 모델 학습 및 예측
    smape_df, mape_df = run_prophet_model_viz_last_day(df[df['num'] == building_num], 
                                                         target_col='power', 
                                                         building_col='num')

    # scaled_df에 대한 Prophet 모델 학습 및 예측
    smape_scaled_df, mape_scaled_df = run_prophet_model_viz_last_day(scaled_df[scaled_df['num'] == building_num], 
                                                                      target_col='power', 
                                                                      building_col='num')

    # 결과 저장
    results = pd.concat([results, pd.DataFrame({
        'num': [building_num],
        'df_raw': [smape_raw],
        'df': [smape_df],
        'scaled_df': [smape_scaled_df]
    })], ignore_index=True)

# CSV 파일로 저장
# results.to_csv('prophet_smape_results_by_building.csv', index=False, encoding='utf-8-sig')
#-------------------------------------------------------------------------

# ------------------------------------------------------------------
#XGBoost --------------

#XGBRegressor는 datetime64 type을 인식하지 못하므로 datetime 64를 hour day month year로 구별한다
# 그리고 인식하지못하는이유는
# 회귀모델이라서 시간 데이터를 제대로 인식하지 못해서 분리해서 해야한다
# year는 변동성이 없으므로 제거
# hour는 변환한 hour가 있지만 있고 돌리고 없고 돌리는 것을 이용한다

df_raw_test_x_xgboost=df_raw_test_x.copy()
df_raw_train_x_xgboost=df_raw_train_x.copy()
df_test_x_xgboost=df_test_x.copy()
df_train_x_xgboost=df_train_x.copy()
scaled_df_test_x_xgboost=scaled_df_test_x.copy()
scaled_df_train_x_xgboost=scaled_df_train_x.copy()

#df _raw
#test
df_raw_test_x_xgboost['date_time'] = pd.to_datetime(df_raw_test_x_xgboost['date_time'], format='%Y-%m-%d %H')
# date_time을 월, 일, 시간으로 분리하여 새로운 열로 추가
# 연도는 필요없으므로 생성하지 않는다
df_raw_test_x_xgboost['월'] = df_raw_test_x_xgboost['date_time'].dt.month
df_raw_test_x_xgboost['일'] = df_raw_test_x_xgboost['date_time'].dt.day
df_raw_test_x_xgboost['시간'] = df_raw_test_x_xgboost['date_time'].dt.hour
# date_time drop
df_raw_test_x_xgboost = df_raw_test_x_xgboost.drop(columns=['date_time'])

# train
df_raw_train_x_xgboost['date_time'] = pd.to_datetime(df_raw_train_x_xgboost['date_time'], format='%Y-%m-%d %H')

df_raw_train_x_xgboost['월'] = df_raw_train_x_xgboost['date_time'].dt.month
df_raw_train_x_xgboost['일'] = df_raw_train_x_xgboost['date_time'].dt.day
df_raw_train_x_xgboost['시간'] = df_raw_train_x_xgboost['date_time'].dt.hour
# date_time drop
df_raw_train_x_xgboost = df_raw_train_x_xgboost.drop(columns=['date_time'])


#df
#test
df_test_x_xgboost['월'] = df_test_x_xgboost['date_time'].dt.month
df_test_x_xgboost['일'] = df_test_x_xgboost['date_time'].dt.day
df_test_x_xgboost['시간'] = df_test_x_xgboost['date_time'].dt.hour
# date_time drop
df_test_x_xgboost = df_test_x_xgboost.drop(columns=['date_time'])


# train
df_train_x_xgboost['월'] = df_train_x_xgboost['date_time'].dt.month
df_train_x_xgboost['일'] = df_train_x_xgboost['date_time'].dt.day
df_train_x_xgboost['시간'] = df_train_x_xgboost['date_time'].dt.hour
# date_time drop
df_train_x_xgboost = df_train_x_xgboost.drop(columns=['date_time'])

# scaled_df
#test
scaled_df_test_x_xgboost['월'] = scaled_df_test_x_xgboost['date_time'].dt.month
scaled_df_test_x_xgboost['일'] = scaled_df_test_x_xgboost['date_time'].dt.day
scaled_df_test_x_xgboost['시간'] = scaled_df_test_x_xgboost['date_time'].dt.hour
# date_time drop
scaled_df_test_x_xgboost = scaled_df_test_x_xgboost.drop(columns=['date_time'])

#train
scaled_df_train_x_xgboost['월'] = scaled_df_train_x_xgboost['date_time'].dt.month
scaled_df_train_x_xgboost['일'] = scaled_df_train_x_xgboost['date_time'].dt.day
scaled_df_train_x_xgboost['시간'] = scaled_df_train_x_xgboost['date_time'].dt.hour
# date_time drop
scaled_df_train_x_xgboost = scaled_df_train_x_xgboost.drop(columns=['date_time'])


#-------------------------------------------------------------
# XGBoost
# df_raw
import xgboost as xgb
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# SMAPE 계산 함수 정의
def smape(y_true, y_pred):
    return 100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred)))

# num별로 결과를 저장할 리스트
smape_results_raw = []

feature_importances_df_raw = {}    # 각 건물별 변수 중요도를 저장할 딕셔너리

# 'cluster' 열 제거
df_raw = df_raw.drop(columns=['cluster'])

# 각 건물(num)에 대해 XGBoost 모델 학습 및 예측 수행
building_numbers = df_raw['num'].unique()

for building in building_numbers:
    print(f"\n건물 {building} 모델 학습 시작...")

    # 해당 건물에 속하는 train/test 데이터 분리
    train_x_num_raw = df_raw_train_x_xgboost[df_raw_train_x_xgboost['num'] == building].drop(columns=['num', 'cluster'])
    train_y_num_raw = df_raw_train_y[df_raw_train_x_xgboost['num'] == building]
    
    test_x_num_raw = df_raw_test_x_xgboost[df_raw_test_x_xgboost['num'] == building].drop(columns=['num', 'cluster'])
    test_y_num_raw = df_raw_test_y[df_raw_test_x_xgboost['num'] == building]

    # XGBoost 모델 생성
    model = xgb.XGBRegressor(
        n_estimators=100,  # 부스팅 트리 개수
        random_state=2020  # randomstate 설정
    )

    # 모델 학습
    model.fit(train_x_num_raw, train_y_num_raw)

    # 예측
    y_pred_num = model.predict(test_x_num_raw)

    # SMAPE 성능 평가
    smape_score = smape(test_y_num_raw, y_pred_num)

    # 결과를 리스트에 추가
    smape_results_raw.append({'num': building, 'SMAPE': smape_score})

    print(f"건물 {building} SMAPE: {smape_score}")

    # 변수 중요도 계산
    feature_importances = model.feature_importances_
    feature_importances_df_raw[building] = feature_importances

    # 변수 중요도 시각화
    plt.figure(figsize=(10, 6))
    plt.barh(train_x_num_raw.columns, feature_importances)
    plt.title(f'건물 {building}의 변수 중요도')
    plt.xlabel('Feature Importance')
    plt.ylabel('Features')
    plt.show()

# 결과를 DataFrame으로 변환
smape_df_raw = pd.DataFrame(smape_results_raw)

# 결과 출력
print(smape_df_raw)




#  df 모델 --------------------------------------

# Object 타입 열만 선택
object_columns_train = df_train_x_xgboost.select_dtypes(include=['object']).columns
object_columns_test = df_test_x_xgboost.select_dtypes(include=['object']).columns

# Object 타입 열에 대해 더미 코딩 적용
df_train_x_xgboost = pd.get_dummies(df_train_x_xgboost, columns=object_columns_train, drop_first=True)
df_test_x_xgboost = pd.get_dummies(df_test_x_xgboost, columns=object_columns_test, drop_first=True)

# 더미 코딩된 열들이 일치하는지 확인 (열이 맞지 않을 경우 문제가 발생할 수 있음)
df_test_x_xgboost = df_test_x_xgboost.reindex(columns=df_train_x_xgboost.columns, fill_value=0)

# num별로 결과를 저장할 리스트
smape_results = []
feature_importances_df = {}    # 각 건물별 변수 중요도를 저장할 딕셔너리
# 각 건물(num)에 대해 XGBoost 모델 학습 및 예측 수행
building_numbers = df_train_x_xgboost['num'].unique()

for building in building_numbers:
    print(f"\n건물 {building} 모델 학습 시작...")

    # 해당 건물에 속하는 train/test 데이터 분리
    train_x_num = df_train_x_xgboost[df_train_x_xgboost['num'] == building].drop(columns=['num'])
    train_y_num = df_train_y[df_train_x_xgboost['num'] == building]
    
    test_x_num = df_test_x_xgboost[df_test_x_xgboost['num'] == building].drop(columns=['num'])
    test_y_num = df_test_y[df_test_x_xgboost['num'] == building]

    # XGBoost 모델 생성
    model = xgb.XGBRegressor(
        n_estimators=100,  # 부스팅 트리 개수
        random_state=2020  # randomstate 설정
    )

    # 모델 학습
    model.fit(train_x_num, train_y_num)

    # 예측
    y_pred_num = model.predict(test_x_num)

    # SMAPE 성능 평가
    smape_score = smape(test_y_num, y_pred_num)

    # 결과를 리스트에 추가
    smape_results.append({'num': building, 'SMAPE': smape_score})

    print(f"건물 {building} SMAPE: {smape_score}")

    # 변수 중요도 계산
    feature_importances = model.feature_importances_
    feature_importances_df[building] = feature_importances

    print(f"건물 {building} SMAPE: {smape_score}")

    # 변수 중요도 시각화
    plt.figure(figsize=(10, 6))
    plt.barh(train_x_num.columns, feature_importances)
    plt.title(f'건물 {building}의 변수 중요도')
    plt.xlabel('Feature Importance')
    plt.ylabel('Features')
    plt.show()

# 결과를 DataFrame으로 변환
smape_df = pd.DataFrame(smape_results)

# 결과 출력
print(smape_df)


#  scaled_df 모델 --------------------------------------

# Object 타입 열만 선택
object_columns_train = scaled_df_train_x_xgboost.select_dtypes(include=['object']).columns
object_columns_test = scaled_df_test_x_xgboost.select_dtypes(include=['object']).columns

# Object 타입 열에 대해 더미 코딩 적용
scaled_df_train_x_xgboost = pd.get_dummies(scaled_df_train_x_xgboost, columns=object_columns_train, drop_first=True)
scaled_df_test_x_xgboost = pd.get_dummies(scaled_df_test_x_xgboost, columns=object_columns_test, drop_first=True)

# 더미 코딩된 열들이 일치하는지 확인 (열이 맞지 않을 경우 문제가 발생할 수 있음)
scaled_df_test_x_xgboost = scaled_df_test_x_xgboost.reindex(columns=scaled_df_train_x_xgboost.columns, fill_value=0)


# num별로 결과를 저장할 리스트
smape_results_scaled = []
feature_importances_dict_scaled_df = {}  # 각 건물별 변수 중요도를 저장할 딕셔너리
# 각 건물(num)에 대해 XGBoost 모델 학습 및 예측 수행
building_numbers_scaled = scaled_df_train_x_xgboost['num'].unique()

for building in building_numbers_scaled:
    print(f"\n건물 {building} 모델 학습 시작...")

    # 해당 건물에 속하는 train/test 데이터 분리
    train_x_num_scaled = scaled_df_train_x_xgboost[scaled_df_train_x_xgboost['num'] == building].drop(columns=['num'])
    train_y_num_scaled = scaled_df_train_y[scaled_df_train_x_xgboost['num'] == building]
    
    test_x_num_scaled = scaled_df_test_x_xgboost[scaled_df_test_x_xgboost['num'] == building].drop(columns=['num'])
    test_y_num_scaled = scaled_df_test_y[scaled_df_test_x_xgboost['num'] == building]

    # XGBoost 모델 생성
    model = xgb.XGBRegressor(
        n_estimators=100,  # 부스팅 트리 개수
        random_state=2020  # randomstate 설정
    )
    
    # 모델 학습
    model.fit(train_x_num_scaled, train_y_num_scaled)

    # 예측
    scaled_df_y_pred_num = model.predict(test_x_num_scaled)

    # SMAPE 성능 평가
    smape_score = smape(test_y_num_scaled, scaled_df_y_pred_num)
    smape_results_scaled.append({'num': building, 'SMAPE': smape_score})

    print(f"건물 {building} SMAPE: {smape_score}")

    # 변수 중요도 계산
    feature_importances = model.feature_importances_
    feature_importances_dict_scaled_df[building] = feature_importances

    print(f"건물 {building} SMAPE: {smape_score}")

    # 변수 중요도 시각화
    plt.figure(figsize=(10, 6))
    plt.barh(train_x_num_scaled.columns, feature_importances)
    plt.title(f'건물 {building}의 변수 중요도')
    plt.xlabel('Feature Importance')
    plt.ylabel('Features')
    plt.show()





# 결과를 DataFrame으로 변환
smape_scaled_df = pd.DataFrame(smape_results_scaled)

# 결과 출력
print(smape_scaled_df)
    
# XGBoost 주요변수 시각화
#df_raw 시각화
# 모든 건물의 변수 중요도를 리스트로 변환
feature_importances_values = list(feature_importances_df_raw.values())

# numpy 배열로 변환 후 평균 계산
feature_importances_avg_df_raw = np.mean(np.array(feature_importances_values), axis=0)

# 변수 이름 가져오기 (모든 건물에 동일한 열을 사용했으므로 첫 번째 열 이름을 사용)
feature_names = train_x_num_raw.columns

# 평균 변수 중요도를 시각화
plt.figure(figsize=(12, 8))
plt.barh(feature_names, feature_importances_avg_df_raw, color='skyblue')
plt.xlabel('Average Importance')
plt.ylabel('Features')
plt.title('Average Feature Importance (XGBoost_df_raw Data)')
plt.grid(True)
plt.show()




# feature_importances_df[의 모든 건물별 변수 중요도를 평균 계산
feature_importances_avg_df = np.mean(list(feature_importances_df.values()), axis=0)

# 변수 이름 가져오기
feature_names = df_train_x_xgboost.drop(columns=['num']).columns

# 변수 중요도를 시각화
plt.figure(figsize=(10, 6))
plt.barh(feature_names, feature_importances_avg_df, color='skyblue')
plt.xlabel('Average Importance')
plt.ylabel('Features')
plt.title('Average Feature Importance (XGBoost_df Data)')
plt.grid(True)
plt.show()



# feature_importances_dict_scaled_df의 모든 건물별 변수 중요도를 평균 계산
feature_importances_avg_scaled_df = np.mean(list(feature_importances_dict_scaled_df.values()), axis=0)

# 변수 이름 가져오기
feature_names = scaled_df_train_x_xgboost.drop(columns=['num']).columns

# 변수 중요도를 시각화
plt.figure(figsize=(10, 6))
plt.barh(feature_names, feature_importances_avg_scaled_df, color='skyblue')
plt.xlabel('Average Importance')
plt.ylabel('Features')
plt.title('Average Feature Importance (XGBoost_Scaled Data)')
plt.grid(True)
plt.show()


